#!/usr/bin/env python

def intro(greet):
    print(greet)

def main():
    intro('Welcome to the Brain Games!')

if __name__ == '__main__':
    main()
    